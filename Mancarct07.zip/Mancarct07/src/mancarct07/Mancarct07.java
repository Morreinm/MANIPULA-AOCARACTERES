package mancarct07;

import java.util.Scanner;

public class Mancarct07 {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        String nome, sep[], abrev;

        System.out.println("digite seu nome completo");
        nome = teclado.nextLine();
        sep = nome.split(" ");

        System.out.print(sep[0] + " ");

        for (int i = 1; i < sep.length - 1; i++) {
            abrev = sep[i].toUpperCase();
            System.out.print(abrev.charAt(0) + ".");
        }

        System.out.println(" " + sep[sep.length - 1]);

    }
}
